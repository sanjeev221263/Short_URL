﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ShortUrl.Logic;
using ShortUrl.Logic.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShortUrl.Logic.Tests
{
    [TestClass()]
    public class UrlManagerTests
    {
       UrlManager _urlManager;
       [TestInitialize]
        public void Initialize()
        {
            _urlManager = new UrlManager();
        }

        [TestMethod()]
        public void AddShortUrlTest_Pass()
        {
            string newKey = _urlManager.AddShortUrl("https://www.google.com");
            Assert.IsNotNull(newKey);
        }

        [TestMethod()]
        [ExpectedException(typeof(InvalidUrlException),"Url is not valid")]
        public void AddShortUrlTest_Fail()
        {
            string newKey = _urlManager.AddShortUrl("com");
        }

        [TestMethod()]
        public void GetUrlTest_Pass()
        {
            string url = _urlManager.GetUrl("0f1bd7");
            Assert.IsNotNull(url);
        }

        [TestMethod()]
        [ExpectedException(typeof(MissingKeyException), "key not found")]
        public void GetUrlTest_Fail()
        {
            string url = _urlManager.GetUrl("hkjhh6");
        }

    }
}