﻿$(document).ready(function () {
    displayfromSession();
    $(document).on('click', shortUrlSubmit, function () {
        shortUrl = new ShortURL(urlInput.val(), '');
        shortUrl.getShortUrl();
    });
    $(document).on('click', shortUrlPlaceholder, function () {
        shortUrl = new ShortURL();
        shortUrl.getFullUrl($(this).attr('id'));
    });
});

function ShortURL(url, key) {
    this.url = url || '',
    this.key = key || ''
}

ShortURL.prototype = {
    constructor: ShortURL,

    getShortUrl: function () {
        if (this.validateUrl())
            newAjax(this.getInputParameter(), this.displayShortUrl, this.handleShortUrlError);
    },

    getFullUrl: function (value) {
        this.navigateToFullUrl(this.getFromSession(value));
    },

    displayShortUrl: function (url,key) {
        (new ShortURL()).pushToSession(url, key);
    },

    navigateToFullUrl: function (value) {
        window.open(value);
    },

    validateUrl: function () {
        if (!urlRegex.test(this.url)) {
            this.handleShortUrlError(urlErrorMessage);
            return false;
        }
        return true;
    },

    handleShortUrlError: function (error) {
        errorPlaceHolder.show();
        errorPlaceHolder.text(error);
    },

    getInputParameter: function () {
        var input = {};
        input.inputData = this.url;
        input.methodName = ShortUrlMethodName;
        return input;
    },

    pushToSession: function (url,key) {
        var urlList = JSON.parse(sessionStorage.getItem(sessionStorageKey));
        if (!urlList) {
            urlList = new Array();
        }
        urlList.push({ 'Key': key, 'URL': url });
        if (urlList.length > 10) {
            urlList.splice(0, 1);
        }
        sessionStorage.setItem(sessionStorageKey, JSON.stringify(urlList));
        displayfromSession();
    },

    getFromSession: function (value) {
        var urlList = JSON.parse(sessionStorage.getItem(sessionStorageKey));
        var urlObj = urlList.filter(function (data) { return data.Key == value; });
        return urlObj[0].URL;
    }
};
