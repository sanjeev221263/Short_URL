﻿newAjax = function (param, successCallback, errorCallback) {
    $.ajax({
        beforeSend: function () {
            errorPlaceHolder.hide();
            ajaxloader.show();
        },
        complete: function () {
            ajaxloader.hide();
        },
        type: 'GET',
        url: serviceEndpoint + param.methodName,
        crossDomain: true,
        data: { inputData: param.inputData },
        dataType: 'json',
        contentType: "application/javascript",
        async: false,
        success: function (data) {
            if (typeof successCallback === 'function') {
                successCallback(param.inputData, data);
            }
        },
        error: function (data) {
            ajaxloader.hide();
            if (typeof errorCallback === 'function') {
                errorCallback(data.responseJSON.ExceptionMessage);
            }
        }
    });
}