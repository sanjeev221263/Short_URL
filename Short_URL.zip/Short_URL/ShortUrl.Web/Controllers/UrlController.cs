﻿using ShortUrl.Logic;
using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace ShortUrl.WebApi.Controllers
{
    public class UrlController : ApiController
    {
        /// <summary>
        /// Returns the URL location for the key
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("{key}")]
        public HttpResponseMessage Get(string key)
        {
            using (UrlManager urlManager = new UrlManager())
            {
                var response = Request.CreateResponse(HttpStatusCode.Moved);
                String urlString = urlManager.GetUrl(key);
                if (!String.IsNullOrWhiteSpace(urlString))
                {
                    response.Headers.Location = new Uri(urlString);
                    return response;
                }
            }
            return null;
        }

        /// <summary>
        /// Returns the short key for the url
        /// </summary>
        /// <param name="inputData"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetShortURL")]
        public HttpResponseMessage GetShortURL(String inputData)
        {
            using (UrlManager urlManager = new UrlManager())
            {
                return Request.CreateResponse(HttpStatusCode.OK, urlManager.AddShortUrl(inputData));
            }
        }
    }
}
