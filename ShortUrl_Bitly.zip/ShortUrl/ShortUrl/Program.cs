﻿    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.IO;
    using System.Text;
    using System.Text.RegularExpressions;

    using System.Security.Cryptography.X509Certificates;
    using System.Net.Security;
    namespace ShortUrl
    {
        class Program
        {
            static void Main(string[] args)
            {
                string groupId = "Bj3ravzSOZ2";
                string token = "5db9c368427bc5d9315479220159f80531fc7285";
                string url = "https://www.allstate.com/about/personalized-insurance-proposal.aspx";

                Shorten(groupId, token, url);
                //GetGroupID(token);
            }

            public static void Shorten(string groupId, string token, string url)
            {
                string post = "{\"group_guid\": \"" + groupId + "\", \"long_url\": \"" + url + "\"}";
                string shortUrl = url;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://api-ssl.bitly.com/v4/shorten");


                try
                {
                    System.Net.ServicePointManager.ServerCertificateValidationCallback = delegate (object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };

                    request.ServicePoint.Expect100Continue = false;
                    request.Method = "POST";
                    request.ContentLength = post.Length;
                    request.ContentType = "application/json";
                    request.Headers.Add("Cache-Control", "no-cache");
                    request.Host = "api-ssl.bitly.com";
                    request.Headers.Add("Authorization", "Bearer " + token);

                    using (Stream requestStream = request.GetRequestStream())
                    {
                        byte[] postBuffer = Encoding.ASCII.GetBytes(post);
                        requestStream.Write(postBuffer, 0, postBuffer.Length);
                    }

                    using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                    {
                        using (Stream responseStream = response.GetResponseStream())
                        {
                            using (StreamReader responseReader = new StreamReader(responseStream))
                            {
                                string json = responseReader.ReadToEnd();
                                shortUrl = Regex.Match(json, @"""link"": ?""(?<link>[^,;]+)""").Groups["link"].Value;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex);
                }

                Console.WriteLine("\nShortened URL: " + shortUrl);
                Console.ReadKey();
            }

        public static void GetGroupID(string token)
        {
            //string post = "{\"group_guid\": \"" + groupId + "\", \"long_url\": \"" + url + "\"}";
            // string shortUrl = url;
            string groups = "";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://api-ssl.bitly.com/v4/groups");


            try
            {
                System.Net.ServicePointManager.ServerCertificateValidationCallback = delegate (object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };

                request.ServicePoint.Expect100Continue = false;
                request.Method = "GET";
                //request.ContentLength = post.Length;
                request.ContentType = "application/json";
                request.Headers.Add("Cache-Control", "no-cache");
                request.Host = "api-ssl.bitly.com";
                request.Headers.Add("Authorization", "Bearer " + token);

                //using (Stream requestStream = request.GetRequestStream())
                //{
                //    byte[] postBuffer = Encoding.ASCII.GetBytes(post);
                //    requestStream.Write(postBuffer, 0, postBuffer.Length);
                //}

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    using (Stream responseStream = response.GetResponseStream())
                    {
                        using (StreamReader responseReader = new StreamReader(responseStream))
                        {
                            string json = responseReader.ReadToEnd();
                            //shortUrl = Regex.Match(json, @"""link"": ?""(?<link>[^,;]+)""").Groups["link"].Value;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex);
            }

            Console.WriteLine("\nShortened URL: " + groups);
            Console.ReadKey();
        }
    }
    }
